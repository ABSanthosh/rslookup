#include <stdio.h>
#include <ctype.h>

int isPrintable(char c) {
  //these are non-space printable characters
  return (c>32 && c<127);
}
int main(void) {
  FILE *infile, *outfile;
  int noChars=0, noWords=0, noLines=0;
  int wordStart=0;
  char c;
  infile=fopen("test1.txt", "r");
  while ((c=getc(infile))!=EOF) {
    if (c=='\n') {noChars++; noLines++; wordStart=0;}
    else if (isspace(c)) {noChars++; wordStart=0;}//whitespace but not new line
         else
            if(isPrintable(c)) {
                noChars++;
                if (!wordStart) {noWords++; wordStart=1;}
            }
  }
  noChars++; noLines++; //EoF has to end a line and is a character
  fclose(infile);
  outfile=fopen("stats.txt","w");
  fprintf(outfile, "Characters=%d, Words=%d, Lines=%d", noChars, noWords, noLines);
  fclose(outfile);
  //Also print on stdout
  printf("Characters=%d, Words=%d, Lines=%d\n", noChars, noWords, noLines);
  return 0;
}
