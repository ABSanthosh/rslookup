#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#define NoCharsInLine 200

int isPunctuation(char c) {
  return (c=='.' || c==',' || c=='!' || c=='?');
}
void writeDate(FILE* outfile, char buf[], int start, int end) {
  for (;start<=end;start++) fputc(buf[start],outfile);
  fprintf(outfile,"\n");
  return;
}

int isPrintable(char c) {
  //these are non-space printable characters that makeup a word
  return (c>32 && c<127);
}

int checkDate(char buf[], int start, int end) {
  char d1=buf[start], d2=buf[start+1], d3=buf[start+2], d4=buf[start+3],
  d5=buf[start+4], d6=buf[start+5], d7=buf[start+6], d8=buf[start+7];
  int zero=(int)'0', day, mth, yr, valid=0;
  int Days[12]={31,29,31,30,31,30,31,31,30,31,30,31};
  if ((end-start==7) && d3=='-' && d6=='-' && isdigit(d1)&& isdigit(d2)
      && isdigit(d4)&& isdigit(d5)&& isdigit(d7) && isdigit(d8)) {
      day=10*(d1-zero)+(d2-zero);
      mth=10*(d4-zero)+(d5-zero);
      yr=10*(d7-zero)+(d8-zero);
      if (mth>0 && mth<13 && mth!=2) valid=(day<=Days[mth-1]);
      else if (mth==2) {
              if (yr==0) valid=(day<=Days[mth-1]);
              else valid=((yr%4==0)? (day<=Days[mth-1]):day<Days[mth-1]);
            }
  }
  return valid;
}
/* Assumes a date is terminated by whitespace or by one of the punctuation
characters ".,!?" or by end of file. A date starts after a whitespace or
at the beginning of a line. */
int main(void) {
  FILE *infile, *outfile;
  const int bufSize=NoCharsInLine;
  char buf[bufSize], c;
  int charno, start, wordStart, format[2]={0,0};
  infile=fopen("test3.txt", "r");
  outfile=fopen("dates.txt", "w");
  if (infile==NULL) {printf("Missing input file\n"); exit(0);}
  while (fgets(buf, bufSize, infile)!=NULL) {//reads one line into buf
    //Extract each word and check if it is a date
    charno=0; wordStart=0;
    while ((c=buf[charno])!='\0') {
      if (isPrintable(c) && !wordStart) {//starts word
        start=charno;
        wordStart=1;
      }
      if ((isspace(c) || isPunctuation(c)) && wordStart) {//word has ended
        wordStart=0;
        //check if word is a date 29-02-00
        if (checkDate(buf, start, charno-1))
          writeDate(outfile, buf, start, charno-1);
      }
      charno++;
    }// 10-03-03    21-07-70
    if (wordStart) //last word in line
      if (checkDate(buf, start, charno-1))
        writeDate(outfile, buf, start, charno-1);
  }// 31-06-20            34-00-89
  fclose(infile); fclose(outfile);
  return 0;
}
