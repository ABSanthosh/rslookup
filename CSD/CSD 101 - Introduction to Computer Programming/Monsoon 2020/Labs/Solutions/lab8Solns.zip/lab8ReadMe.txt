For input just copy the .c file into a file with the relevant file name (like test1.txt or test2.txt etc.). The program will then run on those files as input and you can check whether or not it is running correctly.

If you are running Linux then there is a command line program called wc which does the same thing. There may be minor differences in the answers since the definition of a valid word/ line/ character which is to be counted differs slightly in wc and the given program.

I have embedded a few dates as part of comments in lab8q3.c to test whether or not dates are being correctly recognized using the above strategy.
