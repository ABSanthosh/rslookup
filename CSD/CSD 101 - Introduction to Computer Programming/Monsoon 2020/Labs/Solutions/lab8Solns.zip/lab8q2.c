#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#define NoLines 1000
#define NoCharsInLine 200

/* A word is a sequence of printable characters.*/

typedef char Line[NoCharsInLine];//assumes a line is at most 200
typedef Line Text[NoLines];//assumes a text file has at most 1000 Lines

int isPrintable(char c) {
  //these are non-space printable characters that makeup a word
  return (c>32 && c<127);
}

void reverse(char str[], int start, int end) {
  //reverses the part of the string between indices start and end
  char c;
  while (start<end) {
    c=str[start];
    str[start]=str[end];
    str[end]=c;
    start++; end--;
  }
}
int main(void) {
  FILE *infile, *outfile;
  const int bufSize=NoCharsInLine;
  char buf[bufSize], c;
  Text text;
  int lineno=0, charno, start, end, wordStart;
  infile=fopen("test2.txt", "r");
  if (infile==NULL) {printf("Missing input file\n"); exit(0);}
  while (fgets(buf, bufSize, infile)!=NULL) {//reads one line into buf
    //reverse the whole line - this will reverse each word as well
    reverse(buf, 0, strlen(buf)-1);
    //Now find each word and reverse it to get back the original word
    charno=0; wordStart=0;
    while ((c=buf[charno])!='\0') {
      if (isPrintable(c) && !wordStart) {//starts word
        start=charno;
        wordStart=1;
      }
      if (isspace(c) && wordStart) {//word has ended
        wordStart=0;
        end=charno-1;//marks last character of word
        //reverse word
        reverse(buf, start, end);
      }
      charno++;
    }
    if (wordStart) reverse(buf, start, charno-1); //reverse last word
    strcpy(text[lineno++], buf);//save current line and start on next line
  }
  fclose(infile);
  /*File has been read into text and each line reversed. Now
  write it out in reverse order into outfile.*/
  outfile=fopen("revtest2.txt","w");
  for (--lineno; lineno>-1;lineno--)
    fputs(text[lineno], outfile);
  fclose(outfile);
  return 0;
}
