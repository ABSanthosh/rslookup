#include <stdio.h>
#include <stdlib.h>

struct Node {
  int data;
  struct Node *next, *prev;
};
/* next points to the next Node or is NULL, prev points
to the previous Node or is NULL
*/

struct Node *insert(struct Node *listp, int pos, int info) {
  /*Inserts a Node in list at position pos with data info
    pos>0. If pos>list length then new node added at end.
    If pos<=1 adds at beginning.
  */
  struct Node *newp=malloc(sizeof(struct Node)), *tmp;
  //create new node and initialize fields
  newp->data=info;
  newp->next=NULL;
  newp->prev=NULL;
  if (listp==NULL) listp=newp;
  else
    if (pos<=1) {
      newp->next=listp;
      listp->prev=newp;
      listp=newp;
    }
    else {
    //pos>1. Go to node at pos-1.
    tmp=listp;
    int i=1;
    while ((i++<pos-1) && tmp->next!=NULL) tmp=tmp->next;
    newp->next=tmp->next;
    newp->prev=tmp;
    tmp->next=newp;
  }
  return listp;
}

struct Node *delete(struct Node *listp, int pos) {
  /*Deletes Node at position pos. pos>0.
    If pos> list length then deletes last node.
    If pos<1 deletes first node.
  */
  struct Node  *temp;
  if (listp==NULL) return NULL;
  if (listp->next==NULL) {
    free(listp);
    return NULL;
  }
  if (pos<=1) {
    temp=listp;
    listp=listp->next;
    listp->prev=NULL;
    free(temp);
  }
  else {//pos>1
    int i;
    temp=listp;
    i=1;
    while (i++<pos && temp->next!=NULL) temp=temp->next;
    (temp->prev)->next=temp->next;
    if (temp->next!=NULL) (temp->next)->prev=temp->prev;
    free(temp);//send memory back to store
  }
  return listp;
}

void printNode(struct Node *listp) {
  struct Node *tmp=listp;
  printf("[");
  while (tmp!=NULL) {
    printf("%d ", tmp->data);
    tmp=tmp->next;
  }
  printf("\b]\n");
  return;
}

int len(struct Node *listp) {
  int l=0;
  struct Node *temp=listp;
  while (temp!=NULL) {
    l++;
    temp=temp->next;
  }
  return l;
}

struct Node *rev(struct Node *listp) {
    //reverse prev and next in each node
  struct Node *tmp, *prev=NULL;
  while (listp!=NULL){
    tmp=listp->next;
    listp->next=listp->prev;
    listp->prev=tmp;
    prev=listp;
    listp=tmp;
  }
  return prev;
}

int search(struct Node *listp, int item) {
  //Returns location of item in list if present else -1
  struct Node *temp=listp;
  int ind=1, found=0;
  while (temp!=NULL) {
    if (temp->data==item) {found=1; break;}
    temp=temp->next;
    ind++;
  }
  return found?ind:-1;
}

int main(void) {
  char op;
  int pos, info;
  struct Node *listp=NULL;
  //operation loop
  while (1) {
    printf("Operation add(a)/delete(d)/exit(e)/l(length)/r(reverse)/s(search) = ");
    scanf("%c",&op);
    getchar();//purge the newline
    switch (op){
      case 'a':{
        printf("Give position and data for insert =");
        scanf("%d %d", &pos, &info);
        getchar();//purge the newline char
        listp=insert(listp, pos, info);
        printNode(listp);
        break;}
      case 'd':{
        printf("Give position for delete =");
        scanf("%d", &pos);
        getchar();//purge newline char
        listp=delete(listp, pos);
        printNode(listp);
        break;}
      case 'e': {return 0;}
      case 'l': {printf("Length = %d\n", len(listp)); break;}
      case 'r': {
        listp=rev(listp);
        printNode(listp);
        break;}
      case 's': {
        int item;
        printf("Search for = ");
        scanf("%d", &item); getchar();//read and purge newline
        printf("Location = %d\n", search(listp, item));
        break;
      }
      default: {printf("Illegal operation\n");}
    }
  }
  return 0;
}
