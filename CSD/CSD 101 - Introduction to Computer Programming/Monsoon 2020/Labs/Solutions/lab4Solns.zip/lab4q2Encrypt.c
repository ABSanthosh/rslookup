#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
//This program encrypts text as per lab 4 Q2.
//Input can be in lower case or upper case.

int main(void) {
  char s[150];
  int len=0, shift;
  char c;
  printf("Give the text to be encrypted (<100 chars) then ENTER = ");
  c=toupper(getchar());
  while (!iscntrl(c) && c!=EOF && len<100) {
    if (c==' ') {s[len++]='Q'; s[len++]='Q';}//if blank char add QQ
    else {
      if (c<'A' || c>'Z') {printf("Invalid char in input\n"); exit(0);}
      s[len++]=c;
    }
    c=toupper(getchar());
  }
  s[len++]='Q'; s[len++]='Q';//an extra blank at the end
  printf("Give the shift (1 to 26) then ENTER = ");
  scanf("%d",&shift);
  if (shift<1 || shift>26){printf("INVALID SHIFT VALUE"); exit(0);}
  for (int i=0; i<len; i++) {
    int ci=(int)s[i]+shift;
    c=(ci>(int)'Z')?(char)(ci-(int)'Z'+(int)'A'-1):(char)ci;
    s[i]=c;
  }
  for (int i=0; i<len; i++) {
    if (i%6==0 && i!=0) putchar(' ');
    putchar(s[i]);
  }
  printf("\n");
  return 0;
}
