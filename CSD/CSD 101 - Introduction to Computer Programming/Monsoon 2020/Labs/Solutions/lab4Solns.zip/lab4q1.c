#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
/*The program does not check if the input word is a legal English word */
int letterValue(char c) {
  switch (c) {
    case 'A':case 'E':case 'I':case 'O':case 'U':case 'N':case 'T':case 'L':
    case 'R':case 'S': {return 1;}
    case 'D':case 'G': {return 2;}
    case 'B':case 'C':case 'M':case 'P': {return 3;}
    case 'F':case 'H':case 'V':case 'W':case 'Y': {return 4;}
    case 'K': {return 5;}
    case 'J':case 'X': {return 8;}
    case 'Q':case 'Z': {return 10;}
    default: {printf("Illegal input\n"); exit(0);}
  }
}
int main(void) {
  char s[50];
  int len=0, score=0;
  char c;
  printf("Give the word (<50 chars) then ENTER = ");
  c=getchar();
  while (!iscntrl(c) && c!=EOF && len<51) {
    s[len++]=c;
    c=getchar();
  }
  for (int i=0; i<len; i++)
    score+=letterValue(toupper(s[i]));
  if (len<1) {printf("Null input\n"); return 0;}
  printf("Score for ");
  for (int i=0; i<len; i++) putchar(s[i]);
  printf(" is %d\n", score);
  return 0;
}
