#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

/*Assumes words do not end in Q and QQ is not part of any word. */
int main(void) {
  char s[100];
  int len=0, shift;
  char c;
  printf("Give the coded string (<=100 chars) then ENTER = ");
  c=toupper(getchar());
  while (!iscntrl(c) && c!=EOF && len<101) {
    if (c==' ');//skip space. This is the best time to remove it.
    else {
      if (c<'A' || c>'Z') {printf("Invalid char in input\n"); exit(0);}
      s[len++]=c;
    }
    c=toupper(getchar());
  }
  printf("Give the shift (1 to 26) then ENTER = ");
  scanf("%d",&shift);
  if (shift<1 || shift>26){printf("INVALID SHIFT VALUE\n"); exit(0);}
  //First decode using shift
  for(int i=0; i<len; i++){
    int ci=(int)s[i]-((int)'A'+shift);//ASCII of 'A' is the base
    s[i]=(ci<0)?(26+ci+(int)'A'):(char)(ci+(int)'A');
  }
  //Replace QQ by blank
  int i=0;
  while (i<len) {
    if (s[i]=='Q' && s[i+1]=='Q') {putchar(' '); i+=2;}
    else putchar(s[i++]);
  }
  printf("\n");
  return 0;
}
