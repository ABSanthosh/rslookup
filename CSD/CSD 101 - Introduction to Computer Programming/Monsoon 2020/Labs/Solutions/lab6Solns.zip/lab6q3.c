#include <stdio.h>
#include <ctype.h>
#define N 50

int isPunctuation(char c) {
  return (c=='.' || c==',' || c==';' || c=='"' || c=='?' || c=='!' || c=='\'');
}
int isPalindrome(char a[], int lt, int rt) {
  int val=1;
  //skip if whitespace or punctuation
  if (isspace(a[lt]) || isPunctuation(a[lt])) val=isPalindrome(a,lt+1,rt);
  else {
    if (isspace(a[rt]) || isPunctuation(a[rt])) val=isPalindrome(a,lt,rt-1);
    else {
      if (lt<rt) {
        if (a[lt]==a[rt]) val=isPalindrome(a,lt+1,rt-1);
        else val=0;
      }
    }
  }
  return val;
}
int main(void) {
  char a[N], c;
  int i=0;
  printf("Give string: ");
  c=getchar();
  while (c!=EOF && c!='\n') {
    a[i++]=c;
    c=getchar();
  }
  a[i]='\0';
  printf("String=%s\n",a);
  if (isPalindrome(a,0,i-1)) printf("Yes\n");
  else printf("No\n");
  return 0;
}
