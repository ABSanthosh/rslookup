#include <stdio.h>
#define N 50

void reverse(char a[], int left, int rt) {
  char c;
  if (left<rt) {
    //exchange chars at index left and rt and recurse
    c=a[left];
    a[left]=a[rt];
    a[rt]=c;
    reverse(a,left+1, rt-1);
  }
  return;
}

int main(void) {
  char a[N], c;
  int i=0;
  printf("Give string to be reversed: ");
  c=getchar();
  while (c!=EOF && c!='\n') {
    a[i++]=c;
    c=getchar();
  }
  a[i]='\0';
  printf("String=%s\n",a);
  reverse(a,0,i-1);
  printf("Reversed=%s\n",a);
  return 0;
}
