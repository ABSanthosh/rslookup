#include <stdio.h>
#include <stdlib.h>

long power(int m, int n, int count[]) {
  //m, n not 0 simultaneously
  long val;
  if (m==0) return 0;
  if (n==0) return 1;
  if (n==1) return m;
  if (n%2!=0) {count[0]+=1; val=m*power(m, n-1, count);}
  else {
    val=power(m, n/2, count);
    count[0]+=1;
    val*=val;
  }
  return val;
}

int main(void) {
  int m, n, count[1]={0};
  printf("Give values of m and n = ");
  scanf("%d %d", &m, &n);
  if (m==0 && n==0) {printf("Illegal input\n"); exit(0);}
  long p=power(m, n, count);
  printf("m^n = %ld, mults = %d\n", p, count[0]);
  return 0;
}
