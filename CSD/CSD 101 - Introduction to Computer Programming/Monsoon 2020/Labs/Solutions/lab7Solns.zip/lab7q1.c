#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define N 20

int digitToVal(char d) {
  int val;
  switch (d) {
    case '0': case '1': case '2': case '3': case '4': case '5':
    case '6':case '7': case '8': case '9': {val=(int)d-48; break;}
    case 'A':case 'B':case 'C':case 'D':
    case 'E':case 'F': {val=10+(int)d-65; break;}
    default: {printf("Illegal digit in input\n"); exit(1);}
  }
  return val;
}

char valToDigit(int val) {
  char d;
  if (val<10) d=(char)(48+val);
  else d=(char)(65+(val-10));
  return d;
}


int main(void) {
  char num[N];//stores the number representation as chars
  int b1, b2, n;//the two bases and number of digits in input number
  int val=0, b;//val is the abstract value of the representation
  char d; //digit
  printf("Give number, base of number and base for conversion=");
  scanf("%s%d%d", num, &b1, &b2);
  n=strlen(num);
  b=1;
  for (int i=n-1; i>-1; i--) {
    val+=b*digitToVal(num[i]);
    b*=b1;
  }
  n=0;
  while (val>0) {
    num[n++]=valToDigit(val%b2);//store new representation in same array
    val/=b2;
  }
  for (int i=n-1; i>-1; i--) putchar(num[i]);
  printf("\n");
  return 0;
}
