#include <stdio.h>
#define N 20

void stats(float a[], int n, float *avg, float *mx, float *mn) {
  *mx=(*mn=a[0]);
  *avg=0.0;
  for (int i=0; i<n; i++) {
    *avg+=a[i];
    if (a[i]>(*mx)) *mx=a[i];
    if (a[i]<(*mn)) *mn=a[i];
  }
  *avg=*avg/n;
  return;
}

int main(void) {
  int n;
  float a[N], avg, max, min;
  printf("Array size =");
  scanf("%d", &n);
  for (int i=0; i<n; i++)
    scanf("%f", &a[i]);
  stats(a, n, &avg, &max, &min);
  printf("Avg=%f, Max=%f, Min=%f\n", avg, max, min);
  return 0;
}
