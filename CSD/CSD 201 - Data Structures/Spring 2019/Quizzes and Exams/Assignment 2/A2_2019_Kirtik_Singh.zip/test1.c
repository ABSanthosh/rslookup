#include<stdio.h>
#include<stdbool.h>
#include"1.h"


void main()
{
    list a;
    a->head=NULL;
    int data, option;
    while(1)
    {
        printf("1. Check if list is empty \n");
        printf("2. Length of the list \n");
        printf("3. Print the list \n");
        printf("4. Add as head \n");
        printf("5. Add as tail \n");
        printf("6. Add sorted \n");
        printf("7. Find element \n");
        printf("8. Reverse the list \n");
        printf("9. Remove the head node \n");
        printf("10. Remove value once \n");
        printf("11. Remove all instances \n");
        printf("12. Add all \n");
        printf("13. Exit \n");
        switch(choice)
        {
            case 1:{
                    if(isempty(a)==1)
                        printf("List is empty \n");
					else
						printf("List is not empty \n");
                    }break;
            case 2:{
                    printf("Length of list is %d \n",length(a));
                    } break;
            case 3:{
                    print(a);
            }break;
            case 4:{
                    printf("Enter an element");
                    scanf("%d,&element");
                    if(a->head==NULL)
					{
					    node *temp=a->head;
						temp=(node *)malloc(sizeof(node));
						temp->data=element;
						temp->next=NULL;
                        a->head=temp;
					}
					else
						addAsHead(a,element);
            }break;
            case 5:{
                    printf("Enter an element");
                    scanf("%d,&element");
                    if(a->head==NULL)
					{
					    node *temp=a->head;
						temp=(node *)malloc(sizeof(node));
						temp->data=element;
						temp->next=NULL;
                        a->head=temp;
					}
					else
						addAsTail(a,element);
            }break;
            case 6:{
                    printf("Enter an element");
                    scanf("%d,&element");
                    if(a->head==NULL)
					{
					    node *temp=a->head;
						temp=(node *)malloc(sizeof(node));
						temp->data=element;
						temp->next=NULL;
                        a->head=temp;
					}
					else
						addSorted(a,element);
            }break;
            case 7:{
                    printf("Enter the element to find");
                    int element;
                    scanf("%d,&element");
                    if(find(a,element)==NULL)
                        break;
                    else
                        printf("Element was found");
            }
            case 8:{
                    reverse(a);
                    }break;
            case 9:{
                    printf("The value of the head node is %d",popHead(a);
                    )
                    }break;
            case 10:{
                    int element;
                    printf("Enter an element to delete once");
                    scanf("%d,&element");
                    removeFirst(a,element);
            }
            case 11:{
                    int element;
                    printf("Enter an element to delete once");
                    scanf("%d,&element");
                    removeAll(a,element);
            }
            case 12:{
                addAll(a,b);
            }break;
            case 13:exit(0);
            default:break;
        }
    }
}