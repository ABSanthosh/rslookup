typedef struct Node
{
    int data;
    struct Node *next;
}node;

void display(node *);
void insert(node *,int);
void insertionSort(node *, node *);

