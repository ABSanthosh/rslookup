#include<stdio.h>
#include<stdbool.h>

typedef struct node
{
    int data;
    node *next;
} node;

typedef struct list
{
    node * head;
} list;


bool isEmpty(list *); 
int length(list *);                   // Returns the number of nodes in the list, which is 0 for the empty list; 
void print(list *);                   // print the content of all nodes; 
void addAsHead(list *, int i);          // creates a new node with the integer and adds it to the beginning of the list; 
void addAsTail(list *, int i);          // creates a new node with the integer and adds it to the end of the list; 
void addSorted(list *, int i);          // creates a new node with the integer and adds it behind all nodes with data less or equal to the data of the node, possibly at the end of the list
node *find(list *, int i);               // Returns the first node with data i; 
void reverse(list *);                 // reverses the list; 
int popHead(list *);                  // returns the value of the head of the list and removes the node; if the list is nonempty, otherwise returns NULL; 
void removeFirst (list *, int i);        // removes the first node with value i; 
void removeAll (list *, int i);          // removes all nodes with val i; 
void addAll (list *, list *);            /* appends the list L to the last element of the current list, if the current list is nonempty, or lets the                                       head of the current list point to the first element of L if the current list is empty. */

