#include<stdio.h>
#include<stdbool.h>

typedef struct node
{
    int data;
    node *next;
} node;

typedef struct HTlist
{
    node *head;
    node *tail;
} HTlist;


bool isEmpty(HTlist *); 
int length(HTlist *);                   // Returns the number of nodes in the HTlist, which is 0 for the empty HTlist; 
void print(HTlist *);                   // print the content of all nodes; 
void addAsHead(HTlist *, int i);          // creates a new node with the integer and adds it to the beginning of the HTlist; 
void addAsTail(HTlist *, int i);          // creates a new node with the integer and adds it to the end of the HTlist; 
void addSorted(HTlist *, int i);          // creates a new node with the integer and adds it behind all nodes with data less or equal to the data of the node, possibly at the end of the HTlist
node *find(HTlist *, int i);               // Returns the first node with data i; 
void reverse(HTlist *);                 // reverses the HTlist; 
int popHead(HTlist *);                  // returns the value of the head of the HTlist and removes the node; if the HTlist is nonempty, otherwise returns NULL; 
void removeFirst (HTlist *, int i);        // removes the first node with value i; 
void removeAll (HTlist *, int i);          // removes all nodes with val i; 
void addAll (HTlist *, HTlist *);            /* appends the HTlist L to the last element of the current HTlist, if the current HTlist is nonempty, or lets the                                       head of the current HTlist point to the first element of L if the current HTlist is empty. */

