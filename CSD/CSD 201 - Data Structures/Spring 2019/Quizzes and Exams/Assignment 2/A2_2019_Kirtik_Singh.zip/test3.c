#include<stdio.h>
#include<stdlib.h>
#include"3.h"

void main()
{
    int choice,element;
    node *head=NULL;
    while(1)
    {
        printf("1. Insert new element \n");
        printf("2. Sort the list \n");
        printf("3. Display the list \n");
        printf("4.Exit \n");
        printf("Enter your choice \n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:{
                    printf("Enter an element");
                    scanf("%d,&element");
                    if(head==NULL)
					{
					    node *temp=head;
						temp=(node *)malloc(sizeof(node));
						temp->data=element;
						temp->next=NULL;
                        head=temp;
					}
					else
						insert(head,element);
                    }break;
            case 2:{
                    node *temp=head;
				    while(temp->next!=NULL)
					    temp=temp->next;
	    			insertionSort(head,temp);
		    		printf("The sorted list is :\n");
			    	display(head);
                    } break;
            case 3:{
                    display(head);
            }break;
            case 4:{
                    exit(0);
            }break;
            default:break;
        }
     }
}
