#include<stdio.h>
#include<stdlib.h>
#include"1.h"
#include<stdbool.h>

bool isempty(list *l)
{
    if(l->head==NULL)
        return 1;
    else
        return 0;
}

int length(list *l)
{
    node *crt = l->head;
    int sum=0;
    while(crt!=NULL)
    {
        crt=crt->next;
        sum++;
    }
    return sum;
}

void print(list *l)
{
    node *crt=l->head;
    while(crt!=NULL)
    {
        printf("%d ",crt->data);
    }
}

void addAsHead(list *l, int num)
{
    node *temp=(node*)malloc(sizeof(node));
    temp->data=num;
    temp->next=l->head;
    l->head=x;
}

void addAsTail(list *l, int num)
{
    node *temp= (node*)malloc(sizeof(node));
    temp->data=num;
    temp->next=NULL;
    node *crt=l->head;
    while(crt->next!=NULL)
    {
     	crt=crt->next;
    }
    crt->next=num;
}

node find(list *l, int num)
{
    node *crt=l->head;
    while(crt->data!=num || crt!=NULL)
        crt=crt->data;
    if(crt==NULL)
        printf("Not found \n");
    else
    {
            return crt;
    }
}

void reverse(list *l)
{
    node *new=(node *)malloc(sizeof(node));
 	node *crt=l->head;
  	while(crt->next!=NULL)
  	    crt=crt->next;
  	new=crt;
  	new->next=NULL;
  	while(crt!=l->head)
  	{
  	    node *temp=n;
  	 	while(temp->next!=crt)
  	 		temp=temp->next;
  	 	node  temp=new;
  	 	while(new->next!=NULL)
  	 	    new = new->next;
  	 	new->next = temp;
  	 	new->next->next=NULL;
  	 	new=temp;
  	 	crt=temp;
 	 }
 	 l->head=new;
  }


int popHead(list *l)
{
    if(l->head!=NULL)
    {
        int num=l->head->data;
        node * temp=l->head;
        l->head=l->head->next;
        free(temp);
        return num;
    }
    else
        return NULL;
}

void removeFirst(list *l, int num)
{
    node *crt=l->head;
    while(crt->next->data!=num)
        crt=crt->next;
    node *temp=crt->next;
    crt->next=crt->next->next;
    free(temp);
}

void removeAll(list *l, int num)
{
    node * crt=l->head;
    while(crt!=NULL)
    {
        while(crt->next->data!=num)
            crt=crt->next;
        node * temp=crt->next;
        crt->next=crt->next->next;
        free(temp);
        crt=crt->next;
    }
}

void addALL(list *l,list *m)
{
   if(l->head==NULL)
   l->head=m->head;
   else
    {
        node *crt=l->head;
        while(crt->next!=NULL)
            crt=crt->next;
        crt->next=m->head;
    }
}





