#include<stdio.h>
#include"3.h"
#include<stdlib.h>

void insert(node *head, int element)
{
        node * crt=head;
	    while(crt->next!=NULL)
		    crt=crt->next;
        node * temp;
	    temp=(node *)malloc(sizeof(node));
	    temp->data=element;
    	temp->next=NULL;
	    crt->next=temp;
}

void display(node *head)
{
	node *temp=head;
	while(temp!=NULL)
	{
		printf("%d ",temp->data);
		temp=temp->next;
	}
}

void insertionSort(node *head,node *tail)
{
	node *temp1=head;
	node *temp2=temp1->next;
	while(temp1->next!=NULL)
	{
		if(temp1==tail)
			break;
		temp2=temp1->next;
		if(temp2->data<temp1->data)
		{
			int n;
			n=temp2->data;
			temp2->data=temp1->data;
			temp1->data=n;
			insertionSort(head,temp2);
		}
		temp1=temp1->next;
	}
}
